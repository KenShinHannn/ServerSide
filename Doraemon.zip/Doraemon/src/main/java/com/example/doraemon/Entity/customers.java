package com.example.doraemon.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "customers")
@Setter
@Getter
@ToString
public class customers {
    @Id
    private int customerNumber;
    private String customerName;
    private String city;
    private String country;
    private String phone;
    private String role;

}
