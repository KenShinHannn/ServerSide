package com.example.doraemon.repositories;

import com.example.doraemon.Entity.customers;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;

public class customerRepositories {
    static EntityManagerFactory emf = Persistence.createEntityManagerFactory("classicModels");
    static EntityManager em = emf.createEntityManager();
    public static List<customers> findAll(){
        return em.createQuery("select c from customers c").getResultList(); // select * from customers
    }
}
