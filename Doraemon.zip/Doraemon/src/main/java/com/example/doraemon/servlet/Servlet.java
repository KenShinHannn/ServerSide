package com.example.doraemon.servlet;

import com.example.doraemon.Entity.customers;
import com.example.doraemon.repositories.customerRepositories;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "Servlet", value = "/083/customers")
public class Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<customers> customersList = customerRepositories.findAll();
        request.setAttribute("customers",customersList);
        request.getRequestDispatcher("/customerList.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
