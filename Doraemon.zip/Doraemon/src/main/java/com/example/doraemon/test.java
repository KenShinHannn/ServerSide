package com.example.doraemon;

import com.example.doraemon.Entity.customers;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;

public class test {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("classicModels");
        EntityManager em = emf.createEntityManager();
        List<customers> customersList = em.createQuery("select c from customer c ").getResultList();// jpa query syntax
        customersList.forEach(show -> System.out.println(show));
    }
}
