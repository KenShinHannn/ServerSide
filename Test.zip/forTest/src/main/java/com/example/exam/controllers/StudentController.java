package com.example.exam.controllers;

import com.example.exam.dtos.DtoStudentGrade;
import com.example.exam.entities.Student;
import com.example.exam.services.StudentService;
import com.example.exam.utils.ListMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/083/students")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @GetMapping("")
    public List<Student> getAllStudent(){
        return studentService.getAll();
    }

    @DeleteMapping("/{studentId}")
    private void deleteStudent(@PathVariable Integer studentId, Integer grade) {
        studentService.deleteStudentNotHaveGrade(studentId, grade);
    }
}
