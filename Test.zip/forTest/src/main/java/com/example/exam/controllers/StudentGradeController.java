package com.example.exam.controllers;

import com.example.exam.dtos.DtoStudentGrade;
import com.example.exam.services.StudentGradeService;
import com.example.exam.utils.ListMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/083/studentGrades")
public class StudentGradeController {
    @Autowired
    private StudentGradeService studentGradeService;
    @Autowired
    private ListMapper listMapper;
    @Autowired
    private ModelMapper modelMapper;

    @GetMapping("")
    public List<DtoStudentGrade> getAllStudentGrade(){
        return listMapper.mapList(studentGradeService.getAll(), DtoStudentGrade.class, modelMapper);
    }




}
