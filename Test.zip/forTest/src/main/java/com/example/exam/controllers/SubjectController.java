package com.example.exam.controllers;

import com.example.exam.entities.Subject;
import com.example.exam.services.SubjectService;
import com.example.exam.utils.ListMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/083/subjects")
public class SubjectController {
    @Autowired
    private SubjectService subjectService;


}
