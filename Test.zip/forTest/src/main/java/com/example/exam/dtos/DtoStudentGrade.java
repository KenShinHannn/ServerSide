package com.example.exam.dtos;

import com.example.exam.entities.StudentGrade;
import com.example.exam.entities.Subject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoStudentGrade {
    @Id
    private Integer studentId;
    @JsonProperty("name")
    private String StudentName;

    @JsonProperty("grades")
    private Subject subject;
    @JsonProperty("grade")
    private Double StudentGradeGrade;
//    private StudentGrade studentGrade;
//    private String subjectTitle;
}
