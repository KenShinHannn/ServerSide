package com.example.exam.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Subject {
    @Id
    @JsonIgnore
    private Integer subjectId;

    private String subjectCode;

    @JsonIgnore
    private String title;
    @JsonIgnore
    private Double credit;
}
