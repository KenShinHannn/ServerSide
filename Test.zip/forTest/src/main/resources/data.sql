insert into Subject (subject_Id, subject_Code, title, credit) values (101,'INT101', 'Computer Programming I', 3.0);
insert into Subject (subject_Id, subject_Code, title, credit) values (102,'INT102', 'Computer Programming 2', 2.0);
insert into Subject  (subject_Id,subject_Code, title, credit) values (201,'INT201', 'Front-End Dev 1', 3.0);
insert into Subject (subject_Id,subject_Code, title, credit) values (202,'INT202', 'Back-End Dev 1', 3.0);
insert into Subject (subject_Id,subject_Code, title, credit) values (203,'INT203', 'Front-End Dev 2', 2.5);
insert into Subject (subject_Id,subject_Code, title, credit) values (204,'INT204', 'Back-End Dev 2', 1.0);


insert into student values (08301, 'Saharat-01');
insert into student values (08302, 'Saharat-02');
insert into student values (08303, 'Saharat-03');
insert into student values (08304, 'Saharat-04');
insert into student values (08305, 'Saharat-05');

insert into student_grade (subject_id, student_id,  grade) values(101, 08301, 3.0);
insert into student_grade (subject_id, student_id,  grade) values(102, 08301, 3.5);
insert into student_grade (subject_id, student_id,  grade) values(201, 08301, 3.5);
insert into student_grade (subject_id, student_id,  grade) values(203, 08301,0.0);
insert into student_grade (subject_id, student_id,  grade) values(203, 08301,2.0);
insert into student_grade (subject_id,student_id,  grade) values(101,08305,3.0);
insert into student_grade (subject_id,student_id,  grade) values(102,08305,2.5);
insert into student_grade (subject_id,student_id,  grade) values(201,08305,2.5);
insert into student_grade (subject_id,student_id,  grade) values(204, 08305, 1.0);
