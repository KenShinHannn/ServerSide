package sit.int202.testscope;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "LoginServlet", value = "/Login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("Login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String user = request.getParameter("username");
        String password = request.getParameter("password");
        HttpSession session = request.getSession();
        if("Ken".equals(user) && "1234".equals(password)){
            session.setAttribute("user", user);
            System.out.println("Login Success");
        }
        else if(user == null && user.isEmpty()){
            response.sendError(401);
        }
        response.sendError(401);















//        String user = request.getParameter("username");
//        String pass = request.getParameter("password");
//        HttpSession session = request.getSession();
//        if (user == null || user.isEmpty()) {
//            response.sendError(401);
//        } else if ("boss".equals(user) && "1234".equals(pass)) {
//            session.setAttribute("user", user);
//            System.out.println("Login SumLek");
//            request.getRequestDispatcher("/page1.jsp").forward(request, response);
//        } else {
//            response.sendError(401);
//        }
    }
}
