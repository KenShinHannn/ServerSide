package sit.int202.testscope;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "TestScopeServlet", value = "/TestScope")
public class TestScopeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("rc", "This is a Request Scope"); // request

        HttpSession session = request.getSession();
        session.setAttribute("sc", "This is a Session Scope");

        getServletContext().setAttribute("ac", "This is a Session Scope");
        request.getRequestDispatcher("/test_scope.jsp").forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
